(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./banlist/banlist.module": [
		"./src/app/banlist/banlist.module.ts",
		"banlist-banlist-module"
	],
	"./card-detail/card-detail.module": [
		"./src/app/card-detail/card-detail.module.ts",
		"card-detail-card-detail-module"
	],
	"./duelo/calculadora/calculadora.module": [
		"./src/app/duelo/calculadora/calculadora.module.ts",
		"duelo-calculadora-calculadora-module"
	],
	"./duelo/classico/classico.module": [
		"./src/app/duelo/classico/classico.module.ts",
		"duelo-classico-classico-module"
	],
	"./duelo/duelo.module": [
		"./src/app/duelo/duelo.module.ts",
		"duelo-duelo-module"
	],
	"./duelo/field-center/field-center.module": [
		"./src/app/duelo/field-center/field-center.module.ts",
		"duelo-field-center-field-center-module"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-controller_8.entry.js",
		"common",
		0
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-ios.entry.js",
		"common",
		1
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-md.entry.js",
		"common",
		2
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert-ios.entry.js",
		"common",
		3
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert-md.entry.js",
		"common",
		4
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8-ios.entry.js",
		"common",
		5
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8-md.entry.js",
		"common",
		6
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3-ios.entry.js",
		"common",
		7
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3-md.entry.js",
		"common",
		8
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button-ios.entry.js",
		"common",
		9
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button-md.entry.js",
		"common",
		10
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop-ios.entry.js",
		11
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop-md.entry.js",
		12
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2-ios.entry.js",
		"common",
		13
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2-md.entry.js",
		"common",
		14
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5-ios.entry.js",
		"common",
		15
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5-md.entry.js",
		"common",
		16
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox-ios.entry.js",
		"common",
		17
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox-md.entry.js",
		"common",
		18
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip-ios.entry.js",
		"common",
		19
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip-md.entry.js",
		"common",
		20
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js",
		21
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3-ios.entry.js",
		"common",
		22
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3-md.entry.js",
		"common",
		23
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3-ios.entry.js",
		"common",
		24
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3-md.entry.js",
		"common",
		25
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-img.entry.js",
		26
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-ios.entry.js",
		"common",
		27
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-md.entry.js",
		"common",
		28
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input-ios.entry.js",
		"common",
		29
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input-md.entry.js",
		"common",
		30
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3-ios.entry.js",
		"common",
		31
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3-md.entry.js",
		"common",
		32
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8-ios.entry.js",
		"common",
		33
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8-md.entry.js",
		"common",
		34
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading-ios.entry.js",
		"common",
		35
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading-md.entry.js",
		"common",
		36
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_4-ios.entry.js",
		"common",
		37
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_4-md.entry.js",
		"common",
		38
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal-ios.entry.js",
		"common",
		39
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal-md.entry.js",
		"common",
		40
	],
	"./ion-nav_5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-nav_5.entry.js",
		"common",
		41
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover-ios.entry.js",
		"common",
		42
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover-md.entry.js",
		"common",
		43
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar-ios.entry.js",
		"common",
		44
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar-md.entry.js",
		"common",
		45
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2-ios.entry.js",
		"common",
		46
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2-md.entry.js",
		"common",
		47
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range-ios.entry.js",
		"common",
		48
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range-md.entry.js",
		"common",
		49
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2-ios.entry.js",
		"common",
		50
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2-md.entry.js",
		"common",
		51
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2-ios.entry.js",
		"common",
		52
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2-md.entry.js",
		"common",
		53
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js",
		54
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js",
		"common",
		55
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar-ios.entry.js",
		"common",
		56
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar-md.entry.js",
		"common",
		57
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2-ios.entry.js",
		"common",
		58
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2-md.entry.js",
		"common",
		59
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3-ios.entry.js",
		"common",
		60
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3-md.entry.js",
		"common",
		61
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2-ios.entry.js",
		62
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2-md.entry.js",
		63
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js",
		"common",
		64
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane-ios.entry.js",
		65
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane-md.entry.js",
		66
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-ios.entry.js",
		"common",
		67
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-md.entry.js",
		"common",
		68
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js",
		"common",
		69
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-text.entry.js",
		"common",
		70
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea-ios.entry.js",
		"common",
		71
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea-md.entry.js",
		"common",
		72
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast-ios.entry.js",
		"common",
		73
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast-md.entry.js",
		"common",
		74
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle-ios.entry.js",
		"common",
		75
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle-md.entry.js",
		"common",
		76
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js",
		77
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/duelo/calculadora/calculadora.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/duelo/calculadora/calculadora.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"3\">\n            <ion-icon class=\"icon-back\" name=\"arrow-back\" (click)=\"fecharModal()\"></ion-icon>\n        </ion-col>\n        <ion-col size=\"9\" class=\"ion-text-center\">\n          <h1>{{lifePoints}} {{pontosAlterados}}</h1>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao(7)\">7</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao(8)\">8</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao(9)\">9</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{operationButtonColor}} (click)=\"apertarBotao('+')\">+</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao(4)\">4</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao(5)\">5</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao(6)\">6</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{operationButtonColor}} (click)=\"apertarBotao('-')\">-</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao(1)\">1</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao(2)\">2</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao(3)\">3</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{operationButtonColor}} (click)=\"apertarBotao('*')\">*</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao('0')\">0</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao('00')\">00</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{numberButtonColor}} (click)=\"apertarBotao('000')\">000</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{operationButtonColor}} (click)=\"apertarBotao('/')\">/</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{optionsButtonColor}} (click)=\"rebobinar()\">MEM</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{optionsButtonColor}} (click)=\"apagar('C')\">C</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{operationButtonColor}} (click)=\"apertarBotao('*2')\">*2</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{operationButtonColor}} (click)=\"apertarBotao('/2')\">/2</ion-button>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-button expand=\"full\" size=\"large\" color={{optionsButtonColor}} (click)=\"apagar('DEL')\">DEL</ion-button>\n      </ion-col>\n      <ion-col size=\"9\">\n        <ion-button expand=\"full\" size=\"large\" color=\"success\" (click)=\"realizarOperacao()\">=</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/duelo/field-center/field-center.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/duelo/field-center/field-center.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"vertical-align-content\">\n    <ion-fab vertical=\"center\" horizontal=\"center\" slot=\"fixed\">\n        <ion-fab-button><ion-icon name=\"menu\"></ion-icon></ion-fab-button>\n        <ion-fab-list side=\"top\">\n            <ion-fab-button (click)=\"setDuel(tipoDuelo)\"><ion-icon name=\"refresh\"></ion-icon></ion-fab-button>\n        </ion-fab-list>\n        <ion-fab-list side=\"start\">\n            <ion-fab-button (click)=\"backToHome()\"><ion-icon name=\"home\"></ion-icon></ion-fab-button>\n        </ion-fab-list>\n        <ion-fab-list side=\"end\">\n            <ion-fab-button (click)=\"chooseLuckAlert()\"><ion-icon name=\"radio-button-off\"></ion-icon></ion-fab-button>\n        </ion-fab-list>\n    </ion-fab>\n    <ion-grid class=\"parametros\">\n        <ion-row class=\"parent-row\">\n            <ion-col size=\"12\">\n                <div class=\"ion-text-center\" (click)=\"callCalculadora('j2')\">\n                    <h2 class=\"fontJogador textOrientation\">{{jogador2.jogador}}</h2>\n                    <h1 class=\"textFormat  textOrientation\">{{jogador2.pontosDeVida}}</h1>\n                </div>\n                <ion-fab vertical=\"top\" horizontal=\"start\">\n                    <ion-fab-button class=\"textOrientation\" (click)=\"listening('Jogador 2', jogador2.pontosDeVida)\">\n                        <ion-icon name=\"mic\"></ion-icon>J2\n                    </ion-fab-button>\n                </ion-fab>\n            </ion-col>\n            <ion-col size=\"12\">\n                <div class=\"ion-text-center\" (click)=\"callCalculadora('j1')\">\n                    <h1 class=\"textFormat\">{{jogador1.pontosDeVida}}</h1>\n                    <h2 class=\"fontJogador\">{{jogador1.jogador}}</h2>\n                </div>\n                <ion-fab vertical=\"bottom\" horizontal=\"end\">\n                    <ion-fab-button (click)=\"listening('Jogador 1', jogador1.pontosDeVida)\">\n                        <ion-icon name=\"mic\"></ion-icon>J1\n                    </ion-fab-button>\n                </ion-fab>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/luck/luck.component.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/luck/luck.component.html ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n    {{abc}}\n    <div class=\"position\">\n        <ion-img src=\"../../assets/img/{{result}}.png\"></ion-img>\n    </div>\n</ion-content>\n<ion-footer>\n    <ion-toolbar>\n        <ion-row>\n            <ion-col>\n                <ion-button expand=\"full\" (click)=\"closeModal()\"><ion-icon name=\"arrow-back\"></ion-icon>Voltar</ion-button>\n            </ion-col>\n            <ion-col>\n                <ion-button expand=\"full\" (click)=\"toss(option)\"><ion-icon name=\"refresh\"></ion-icon>Repetir</ion-button>\n            </ion-col>\n        </ion-row>\n    </ion-toolbar>\n</ion-footer>");

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



const routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', loadChildren: () => __webpack_require__.e(/*! import() | home-home-module */ "home-home-module").then(__webpack_require__.bind(null, /*! ./home/home.module */ "./src/app/home/home.module.ts")).then(m => m.HomePageModule) },
    { path: 'duelo', loadChildren: './duelo/duelo.module#DueloPageModule' },
    { path: 'field-center', loadChildren: './duelo/field-center/field-center.module#FieldCenterPageModule' },
    { path: 'classico', loadChildren: './duelo/classico/classico.module#ClassicoPageModule' },
    { path: 'calculadora', loadChildren: './duelo/calculadora/calculadora.module#CalculadoraPageModule' },
    { path: 'banlist', loadChildren: './banlist/banlist.module#BanlistPageModule' },
    { path: 'card-detail/:name', loadChildren: './card-detail/card-detail.module#CardDetailPageModule' },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");






const { AdMob } = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"];
let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.initializeApp();
        AdMob.initialize("ca-app-pub-6210301466309831~3614300703");
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            this.splashScreen.hide();
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
        _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
        _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]])
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "./node_modules/@ionic-native/in-app-browser/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var src_app_provider_ygo_database_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/provider/ygo/database.service */ "./src/app/provider/ygo/database.service.ts");
/* harmony import */ var _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/http/ngx */ "./node_modules/@ionic-native/http/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/speech-recognition/ngx */ "./node_modules/@ionic-native/speech-recognition/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/network/ngx */ "./node_modules/@ionic-native/network/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic-native/insomnia/ngx */ "./node_modules/@ionic-native/insomnia/__ivy_ngcc__/ngx/index.js");

















let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"]],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] },
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_9__["ScreenOrientation"],
            _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_10__["InAppBrowser"],
            src_app_provider_ygo_database_service__WEBPACK_IMPORTED_MODULE_11__["DatabaseService"],
            _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_12__["HTTP"],
            _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_13__["SpeechRecognition"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_14__["SharedModule"],
            _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_15__["Network"],
            _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_16__["Insomnia"]
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/duelo/calculadora/calculadora.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/duelo/calculadora/calculadora.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2R1ZWxvL2NhbGN1bGFkb3JhL2NhbGN1bGFkb3JhLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/duelo/calculadora/calculadora.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/duelo/calculadora/calculadora.page.ts ***!
  \*******************************************************/
/*! exports provided: CalculadoraPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CalculadoraPage", function() { return CalculadoraPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");




let CalculadoraPage = class CalculadoraPage {
    constructor(alertController, modalController, screen, navParams) {
        this.alertController = alertController;
        this.modalController = modalController;
        this.screen = screen;
        this.navParams = navParams;
        this.lifePoints = "";
        this.pontosAlterados = "";
        this.pontosMemoria = "";
        //Definir cor dos botoes
        this.numberButtonColor = "dark";
        this.operationButtonColor = "danger";
        this.optionsButtonColor = "warning";
        this.lifePoints = this.navParams.get('lifePoints');
        this.orientacao = this.navParams.get('orientacao');
        this.jogador = this.navParams.get('jogador');
        this.mudarOrientacao();
    }
    apertarBotao(botao) {
        this.pontosAlterados = this.pontosAlterados + botao;
    }
    realizarOperacao() {
        try {
            if (this.pontosAlterados.startsWith("+") || this.pontosAlterados.startsWith("-") || this.pontosAlterados.startsWith("*") || this.pontosAlterados.startsWith("/") || this.pontosAlterados.startsWith("(")) {
                this.pontosMemoria = this.lifePoints;
                this.lifePoints = eval(this.lifePoints + this.pontosAlterados);
                if (Number(this.lifePoints) < 0) {
                    this.lifePoints = "0";
                }
                this.pontosAlterados = "";
                this.fecharModal();
            }
            else {
                this.alertErro();
            }
        }
        catch (e) {
            this.alertErro();
        }
    }
    apagar(tipo) {
        if (tipo === "C") {
            this.pontosAlterados = "";
        }
        else if (tipo === "DEL") {
            this.pontosAlterados = this.pontosAlterados.substring(0, this.pontosAlterados.length - 1);
        }
    }
    rebobinar() {
        if (this.pontosMemoria != "") {
            this.lifePoints = this.pontosMemoria;
        }
    }
    alertErro() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create();
            alert.title = "Erro";
            alert.subHeader = "Digite uma operação valida";
            alert.buttons = [
                {
                    text: "Ok",
                    handler: () => {
                        this.pontosAlterados = "";
                    }
                }
            ];
            alert.present();
        });
    }
    fecharModal() {
        this.modalController.dismiss({
            'lifePoints': this.lifePoints,
            'jogador': this.jogador,
            'pontosMemoria': this.pontosMemoria
        });
    }
    mudarOrientacao() {
        if (this.orientacao === 'normal') {
            this.screen.lock(this.screen.ORIENTATIONS.PORTRAIT_PRIMARY);
        }
        else if (this.orientacao === 'invertido') {
            this.screen.lock(this.screen.ORIENTATIONS.PORTRAIT_SECONDARY);
        }
    }
    ngOnInit() {
    }
};
CalculadoraPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__["ScreenOrientation"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] }
];
CalculadoraPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-calculadora',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./calculadora.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/duelo/calculadora/calculadora.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./calculadora.page.scss */ "./src/app/duelo/calculadora/calculadora.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_3__["ScreenOrientation"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"]])
], CalculadoraPage);



/***/ }),

/***/ "./src/app/duelo/field-center/field-center.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/duelo/field-center/field-center.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #fff url('fieldcenter.jpg') no-repeat center center /100% 100%;\n}\n\n.textFormat {\n  font-size: 75px;\n  color: #fff;\n}\n\n.fontJogador {\n  font-size: 50px;\n  color: #fff;\n}\n\n.textOrientation {\n  transform: rotate(180deg);\n}\n\nion-grid.parametros {\n  height: 100% !important;\n}\n\nion-row.parent-row {\n  height: 100% !important;\n  align-items: center !important;\n  justify-content: center !important;\n}\n\nion-fab-button {\n  --background: grey !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZHVlbG8vZmllbGQtY2VudGVyL0Q6XFxQYXJhIG8gb3V0cm8gcGNcXERvY3VtZW50b3NcXFByb2pldG9zIFByb3ByaW9zXFx5Z29DYWxjdWxhdG9yXFx5Z29DYWxjdWxhdG9yL3NyY1xcYXBwXFxkdWVsb1xcZmllbGQtY2VudGVyXFxmaWVsZC1jZW50ZXIucGFnZS5zY3NzIiwic3JjL2FwcC9kdWVsby9maWVsZC1jZW50ZXIvZmllbGQtY2VudGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLDRFQUFBO0FDQVI7O0FESUk7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQ0RSOztBRElJO0VBQ0ksZUFBQTtFQUNBLFdBQUE7QUNEUjs7QURJSTtFQUNJLHlCQUFBO0FDRFI7O0FES0k7RUFDSSx1QkFBQTtBQ0ZSOztBREtJO0VBQ0ksdUJBQUE7RUFDQSw4QkFBQTtFQUNBLGtDQUFBO0FDRlI7O0FES0k7RUFDSSw2QkFBQTtBQ0ZSIiwiZmlsZSI6InNyYy9hcHAvZHVlbG8vZmllbGQtY2VudGVyL2ZpZWxkLWNlbnRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbiAgICBpb24tY29udGVudHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmIHVybCgnLi4vLi4vLi4vYXNzZXRzL2ltZy9maWVsZGNlbnRlci5qcGcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvMTAwJSAxMDAlO1xuICAgICAgICBcbiAgICB9XG4gICAgIFxuICAgIC50ZXh0Rm9ybWF0e1xuICAgICAgICBmb250LXNpemU6IDc1cHg7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgIH1cblxuICAgIC5mb250Sm9nYWRvcntcbiAgICAgICAgZm9udC1zaXplOiA1MHB4O1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICB9XG5cbiAgICAudGV4dE9yaWVudGF0aW9ue1xuICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xuICAgIH1cblxuXG4gICAgaW9uLWdyaWQucGFyYW1ldHJvc3tcbiAgICAgICAgaGVpZ2h0OjEwMCUgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICBpb24tcm93LnBhcmVudC1yb3d7XG4gICAgICAgIGhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyICFpbXBvcnRhbnQ7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyICFpbXBvcnRhbnQ7XG4gICAgfVxuXG4gICAgaW9uLWZhYi1idXR0b257XG4gICAgICAgIC0tYmFja2dyb3VuZDogZ3JleSAhaW1wb3J0YW50O1xuICAgIH1cblxuXG5cbiIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmIHVybChcIi4uLy4uLy4uL2Fzc2V0cy9pbWcvZmllbGRjZW50ZXIuanBnXCIpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8xMDAlIDEwMCU7XG59XG5cbi50ZXh0Rm9ybWF0IHtcbiAgZm9udC1zaXplOiA3NXB4O1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLmZvbnRKb2dhZG9yIHtcbiAgZm9udC1zaXplOiA1MHB4O1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLnRleHRPcmllbnRhdGlvbiB7XG4gIHRyYW5zZm9ybTogcm90YXRlKDE4MGRlZyk7XG59XG5cbmlvbi1ncmlkLnBhcmFtZXRyb3Mge1xuICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbn1cblxuaW9uLXJvdy5wYXJlbnQtcm93IHtcbiAgaGVpZ2h0OiAxMDAlICFpbXBvcnRhbnQ7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXIgIWltcG9ydGFudDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbn1cblxuaW9uLWZhYi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6IGdyZXkgIWltcG9ydGFudDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/duelo/field-center/field-center.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/duelo/field-center/field-center.page.ts ***!
  \*********************************************************/
/*! exports provided: FieldCenterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FieldCenterPage", function() { return FieldCenterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");
/* harmony import */ var _calculadora_calculadora_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../calculadora/calculadora.page */ "./src/app/duelo/calculadora/calculadora.page.ts");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/speech-recognition/ngx */ "./node_modules/@ionic-native/speech-recognition/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _luck_luck_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../luck/luck.component */ "./src/app/luck/luck.component.ts");
/* harmony import */ var _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/insomnia/ngx */ "./node_modules/@ionic-native/insomnia/__ivy_ngcc__/ngx/index.js");









let FieldCenterPage = class FieldCenterPage {
    constructor(router, modalController, screen, speech, zone, alertController, insomnia) {
        this.router = router;
        this.modalController = modalController;
        this.screen = screen;
        this.speech = speech;
        this.zone = zone;
        this.alertController = alertController;
        this.insomnia = insomnia;
        this.tipoDuelo = "";
        this.getTipoDuelo();
    }
    ngOnInit() {
        this.setScreenActive();
    }
    getTipoDuelo() {
        let getNav = this.router.getCurrentNavigation();
        if (getNav.extras.state) {
            this.tipoDuelo = getNav.extras.state.tipo;
            this.setDuel(this.tipoDuelo);
        }
    }
    setDuelistas(jogador) {
        var jogador = jogador;
        return jogador;
    }
    callCalculadora(jogador) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let lifePoints;
            let orientacaoTela;
            let pontosMemoria;
            if (jogador === 'j1') {
                lifePoints = this.jogador1.pontosDeVida;
                orientacaoTela = this.jogador1.orientacao;
                pontosMemoria = this.jogador1.pontosMemoria;
            }
            else if (jogador === 'j2') {
                lifePoints = this.jogador2.pontosDeVida;
                orientacaoTela = this.jogador2.orientacao;
                pontosMemoria = this.jogador2.pontosMemoria;
            }
            const modal = yield this.modalController.create({
                component: _calculadora_calculadora_page__WEBPACK_IMPORTED_MODULE_4__["CalculadoraPage"],
                componentProps: {
                    'lifePoints': lifePoints,
                    'orientacao': orientacaoTela,
                    'jogador': jogador,
                    'pontosMemoria': pontosMemoria
                }
            });
            modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data.jogador === 'j1') {
                this.jogador1.pontosDeVida = data.lifePoints;
                this.jogador1.pontosMemoria = data.pontosMemoria;
            }
            else if (data.jogador === 'j2') {
                this.jogador2.pontosDeVida = data.lifePoints;
                this.jogador2.pontosMemoria = data.pontosMemoria;
            }
            this.screen.lock(this.screen.ORIENTATIONS.PORTRAIT_PRIMARY);
        });
    }
    listening(jogador, pontosDeVida) {
        this.getPermission();
        let options = {
            prompt: "Diga " + pontosDeVida + " e a operação. " +
                "Ex: " + pontosDeVida + " - 5000, " + pontosDeVida + " + 1000",
            showPopup: true,
            showPartial: true
        };
        this.speech.startListening(options).subscribe((matches) => {
            if (matches[0].search(pontosDeVida + " ") !== -1) {
                let operacao;
                if (matches[0].indexOf(" x ") !== -1) {
                    operacao = matches[0].replace(" x ", " * ");
                }
                else {
                    operacao = matches[0];
                }
                if (eval(operacao) < 0) {
                    operacao = "0";
                }
                if (jogador === 'Jogador 1') {
                    console.log(matches[0]);
                    this.jogador1.pontosMemoria = pontosDeVida;
                    this.jogador1.pontosDeVida = eval(operacao);
                }
                else {
                    this.jogador2.pontosMemoria = pontosDeVida;
                    this.jogador2.pontosDeVida = eval(operacao);
                }
                this.zone.run(() => {
                    console.log('recarregado');
                });
            }
            else {
                alert("Pronuncie corretamente seus pontos de vida atuais");
            }
        }, (error) => {
            console.log(error);
        });
    }
    getPermission() {
        this.speech.hasPermission().then((hasPermission) => {
            if (!hasPermission) {
                this.speech.requestPermission().then(() => console.log("Permitido"), () => console.log("Negado"));
            }
        });
    }
    backToHome() {
        this.router.navigate(["/home"]);
    }
    setDuel(tipoDuelo) {
        if (tipoDuelo === "dueloClassico") {
            this.jogador1 = this.setDuelistas({ jogador: "Jogador 1", pontosDeVida: "8000",
                orientacao: "normal", pontosMemoria: "" });
            this.jogador2 = this.setDuelistas({ jogador: "Jogador 2", pontosDeVida: "8000",
                orientacao: "invertido", pontosMemoria: "" });
        }
        else if (tipoDuelo === "speedDuel") {
            this.jogador1 = this.setDuelistas({ jogador: "Jogador 1", pontosDeVida: "4000",
                orientacao: "normal", pontosMemoria: "" });
            this.jogador2 = this.setDuelistas({ jogador: "Jogador 2", pontosDeVida: "4000",
                orientacao: "invertido", pontosMemoria: "" });
        }
    }
    chooseLuckAlert() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let alert = yield this.alertController.create();
            let type;
            alert.message = "Escolha qual a forma de tirar a sorte!";
            alert.buttons = [{
                    text: "Cara ou Coroa",
                    handler: () => {
                        this.showLuckModal("Cara ou Coroa");
                    }
                }, {
                    text: "Dados",
                    handler: () => {
                        this.showLuckModal("Dados");
                    }
                }];
            alert.present();
        });
    }
    showLuckModal(tipo) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const luckModal = yield this.modalController.create({
                component: _luck_luck_component__WEBPACK_IMPORTED_MODULE_7__["LuckComponent"],
                componentProps: {
                    type: tipo
                }
            });
            luckModal.present();
            yield luckModal.onWillDismiss();
        });
    }
    setScreenActive() {
        this.insomnia.keepAwake();
    }
};
FieldCenterPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__["ScreenOrientation"] },
    { type: _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_6__["SpeechRecognition"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_8__["Insomnia"] }
];
FieldCenterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-field-center',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./field-center.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/duelo/field-center/field-center.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./field-center.page.scss */ "./src/app/duelo/field-center/field-center.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
        _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_5__["ScreenOrientation"], _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_6__["SpeechRecognition"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
        _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_8__["Insomnia"]])
], FieldCenterPage);



/***/ }),

/***/ "./src/app/luck/luck.component.scss":
/*!******************************************!*\
  !*** ./src/app/luck/luck.component.scss ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-img {\n  width: 250px;\n  height: 250px;\n}\n\n.position {\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%) !important;\n}\n\nion-content {\n  --background: black !important;\n}\n\nion-toolbar {\n  --background: gray !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbHVjay9EOlxcUGFyYSBvIG91dHJvIHBjXFxEb2N1bWVudG9zXFxQcm9qZXRvcyBQcm9wcmlvc1xceWdvQ2FsY3VsYXRvclxceWdvQ2FsY3VsYXRvci9zcmNcXGFwcFxcbHVja1xcbHVjay5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvbHVjay9sdWNrLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtFQUNBLGFBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSwyQ0FBQTtBQ0NKOztBREVBO0VBQ0ksOEJBQUE7QUNDSjs7QURFQTtFQUNJLDZCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9sdWNrL2x1Y2suY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taW1ne1xyXG4gICAgd2lkdGg6IDI1MHB4O1xyXG4gICAgaGVpZ2h0OiAyNTBweDtcclxufVxyXG5cclxuLnBvc2l0aW9ue1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tY29udGVudHtcclxuICAgIC0tYmFja2dyb3VuZDogYmxhY2sgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IGdyYXkgIWltcG9ydGFudDtcclxufSIsImlvbi1pbWcge1xuICB3aWR0aDogMjUwcHg7XG4gIGhlaWdodDogMjUwcHg7XG59XG5cbi5wb3NpdGlvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogNTAlO1xuICB0b3A6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSkgIWltcG9ydGFudDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IGJsYWNrICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiBncmF5ICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/luck/luck.component.ts":
/*!****************************************!*\
  !*** ./src/app/luck/luck.component.ts ***!
  \****************************************/
/*! exports provided: LuckComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LuckComponent", function() { return LuckComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ "./node_modules/@ionic-native/screen-orientation/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");




let LuckComponent = class LuckComponent {
    constructor(screen, navParams, modalController) {
        this.screen = screen;
        this.navParams = navParams;
        this.modalController = modalController;
        this.option = this.navParams.get("type");
        this.toss(this.option);
    }
    ngOnInit() {
    }
    caraOuCoroa() {
        let min = Math.ceil(1);
        let max = Math.floor(2);
        let valor = Math.floor(Math.random() * (max - min + 1)) + min;
        return (valor === 1) ? "Cara" : "Coroa";
        /*if(valor === 1){
          return "Cara";
        }else{
          return "Coroa";
        }*/
    }
    dados() {
        let min = Math.ceil(1);
        let max = Math.ceil(6);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    toss(option) {
        var count = 10;
        setInterval(() => {
            if (count > 0) {
                this.result = option === "Cara ou Coroa" ? this.caraOuCoroa() : this.dados();
                /*
                if(option === "Cara ou Coroa"){
                  this.result = this.caraOuCoroa();
                }else if(option === "Dados"){
                  this.result = this.dados();
                }*/
                count = --count;
            }
        }, 150);
    }
    closeModal() {
        this.modalController.dismiss();
    }
};
LuckComponent.ctorParameters = () => [
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_2__["ScreenOrientation"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavParams"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
LuckComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-luck',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./luck.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/luck/luck.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./luck.component.scss */ "./src/app/luck/luck.component.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_2__["ScreenOrientation"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]])
], LuckComponent);



/***/ }),

/***/ "./src/app/provider/ygo/database.service.ts":
/*!**************************************************!*\
  !*** ./src/app/provider/ygo/database.service.ts ***!
  \**************************************************/
/*! exports provided: DatabaseService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DatabaseService", function() { return DatabaseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/http/ngx */ "./node_modules/@ionic-native/http/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");




let DatabaseService = class DatabaseService {
    constructor(http, alertController) {
        this.http = http;
        this.alertController = alertController;
    }
    getAllBanData() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var banlist;
            yield this.http.get('https://db.ygoprodeck.com/api/v7/cardinfo.php?banlist=tcg', {}, {}).then(resposta => {
                this.alertView("Banco de dados carregado");
                resposta.data = JSON.parse(resposta.data);
                banlist = resposta.data.data;
                console.log(banlist);
            }).catch(err => {
                console.log(err.error);
            });
            return banlist;
        });
    }
    getAllCards() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var cards;
            yield this.http.get('https://db.ygoprodeck.com/api/v7/cardinfo.php', {}, {}).then(response => {
                this.alertView("Banco de dados carregado");
                response.data = JSON.parse(response.data);
                cards = response.data;
            }).catch(err => {
                console.log(err.error);
            });
            return cards;
        });
    }
    getSpecificCard(card) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let foundCard;
            yield this.http.get('https://db.ygoprodeck.com/api/v7/cardinfo.php?name=' + card + "", {}, {}).then(response => {
                response.data = JSON.parse(response.data);
                foundCard = response.data.data;
            }).catch(err => {
                console.log(err.error);
            });
            return foundCard;
        });
    }
    alertView(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: message
            });
            alert.buttons = ["OK"];
            alert.present();
        });
    }
};
DatabaseService.ctorParameters = () => [
    { type: _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_2__["HTTP"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] }
];
DatabaseService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_2__["HTTP"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]])
], DatabaseService);



/***/ }),

/***/ "./src/app/shared/shared.module.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _duelo_calculadora_calculadora_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../duelo/calculadora/calculadora.page */ "./src/app/duelo/calculadora/calculadora.page.ts");
/* harmony import */ var _duelo_field_center_field_center_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../duelo/field-center/field-center.page */ "./src/app/duelo/field-center/field-center.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");
/* harmony import */ var _luck_luck_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../luck/luck.component */ "./src/app/luck/luck.component.ts");







let SharedModule = class SharedModule {
};
SharedModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_duelo_calculadora_calculadora_page__WEBPACK_IMPORTED_MODULE_3__["CalculadoraPage"], _duelo_field_center_field_center_page__WEBPACK_IMPORTED_MODULE_4__["FieldCenterPage"], _luck_luck_component__WEBPACK_IMPORTED_MODULE_6__["LuckComponent"]],
        entryComponents: [_duelo_calculadora_calculadora_page__WEBPACK_IMPORTED_MODULE_3__["CalculadoraPage"], _luck_luck_component__WEBPACK_IMPORTED_MODULE_6__["LuckComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"]
        ],
        exports: [
            _duelo_calculadora_calculadora_page__WEBPACK_IMPORTED_MODULE_3__["CalculadoraPage"],
            _duelo_field_center_field_center_page__WEBPACK_IMPORTED_MODULE_4__["FieldCenterPage"]
        ]
    })
], SharedModule);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Para o outro pc\Documentos\Projetos Proprios\ygoCalculator\ygoCalculator\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map