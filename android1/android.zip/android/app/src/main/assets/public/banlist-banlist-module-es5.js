function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["banlist-banlist-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/banlist/banlist.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/banlist/banlist.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppBanlistBanlistPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-row>\n      <ion-col size=\"3\">\n          <ion-icon name=\"arrow-back\" (click)=\"backToMenu()\" class=\"icon-back\"></ion-icon>\n      </ion-col>\n      <ion-col size=\"9\">\n        <h3>Banlist</h3>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-searchbar (ionInput)=\"searchBanCard($event)\" placeholder=\"Digite o nome do card\"></ion-searchbar>\n\n  <div *ngIf=\"!isSearch\">\n    <ion-row>\n      <ion-col size=\"6\" *ngFor = \"let option of options\">\n        <ion-checkbox [(ngModel)]=\"option.checked\"></ion-checkbox>\n        <ion-label>{{option.name}}</ion-label>\n      </ion-col>\n    </ion-row>\n</div>\n\n  <ion-row>\n    <ion-col size=\"4\">\n      <h2>Card</h2>\n    </ion-col>\n    <ion-col size=\"4\">\n      <h2>Nome</h2>\n    </ion-col>\n    <ion-col size=\"4\">\n      <h2>Status</h2>\n    </ion-col>\n  </ion-row>\n\n  <div *ngIf=\"isSearch\">\n    <ion-list *ngFor='let card of searchCard'>\n      <ion-item class={{card.cardType}} button (click)=\"goToDetails(card.cardName, card.cardType)\">\n          <ion-row>\n            <ion-col size=\"4\">\n              <img src={{card.imgPath}}>\n            </ion-col>\n            <ion-col size=\"4\">\n              <h6>{{card.cardName}}</h6>\n            </ion-col>\n            <ion-col size=\"4\">\n              <h6>{{card.cardStatus}}</h6>\n            </ion-col>\n          </ion-row>\n      </ion-item>\n    </ion-list>\n  </div>\n\n  <div *ngIf=\"options[1].checked === true || options[0].checked === true\">\n    <ion-list  *ngFor='let card of banned'>\n      <ion-item class={{card.cardType}} button (click)=\"goToDetails(card.cardName, card.cardType)\">\n          <ion-row>\n            <ion-col size=\"4\">\n              <img src={{card.imgPath}}>\n            </ion-col>\n            <ion-col size=\"4\">\n              <h6>{{card.cardName}}</h6>\n            </ion-col>\n            <ion-col size=\"4\">\n              <h6>{{card.cardStatus}}</h6>\n            </ion-col>\n          </ion-row>\n      </ion-item>\n    </ion-list>\n  </div>\n\n  <div *ngIf=\"options[2].checked === true || options[0].checked === true\">\n    <ion-list  *ngFor='let card of limited'>\n      <ion-item class={{card.cardType}} button (click)=\"goToDetails(card.cardName, card.cardType)\">\n          <ion-row>\n            <ion-col size=\"4\">\n              <img src={{card.imgPath}}>\n            </ion-col>\n            <ion-col size=\"4\">\n              <h6>{{card.cardName}}</h6>\n            </ion-col>\n            <ion-col size=\"4\">\n              <h6>{{card.cardStatus}}</h6>\n            </ion-col>\n          </ion-row>\n      </ion-item>\n    </ion-list>\n  </div>\n  \n  <div *ngIf=\"options[3].checked === true || options[0].checked === true\">\n    <ion-list  *ngFor='let card of semi'>\n      <ion-item class={{card.cardType}} button (click)=\"goToDetails(card.cardName, card.cardType)\">\n          <ion-row>\n            <ion-col size=\"4\" >\n              <img src={{card.imgPath}}>\n            </ion-col>\n            <ion-col size=\"4\">\n              <h6>{{card.cardName}}</h6>\n            </ion-col>\n            <ion-col size=\"4\">\n              <h6>{{card.cardStatus}}</h6>\n            </ion-col>\n          </ion-row>\n      </ion-item>\n    </ion-list>\n  </div>\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/banlist/banlist.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/banlist/banlist.module.ts ***!
    \*******************************************/

  /*! exports provided: BanlistPageModule */

  /***/
  function srcAppBanlistBanlistModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BanlistPageModule", function () {
      return BanlistPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");
    /* harmony import */


    var _banlist_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./banlist.page */
    "./src/app/banlist/banlist.page.ts");

    var routes = [{
      path: '',
      component: _banlist_page__WEBPACK_IMPORTED_MODULE_6__["BanlistPage"]
    }];

    var BanlistPageModule = function BanlistPageModule() {
      _classCallCheck(this, BanlistPageModule);
    };

    BanlistPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_banlist_page__WEBPACK_IMPORTED_MODULE_6__["BanlistPage"]]
    })], BanlistPageModule);
    /***/
  },

  /***/
  "./src/app/banlist/banlist.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/banlist/banlist.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppBanlistBanlistPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "img {\n  width: 75px;\n  height: 100px;\n}\n\nion-list {\n  background-color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYmFubGlzdC9EOlxcUGFyYSBvIG91dHJvIHBjXFxEb2N1bWVudG9zXFxQcm9qZXRvcyBQcm9wcmlvc1xceWdvQ2FsY3VsYXRvclxceWdvQ2FsY3VsYXRvci9zcmNcXGFwcFxcYmFubGlzdFxcYmFubGlzdC5wYWdlLnNjc3MiLCJzcmMvYXBwL2Jhbmxpc3QvYmFubGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtBQ0NKOztBRElBO0VBQ0ksdUJBQUE7QUNESiIsImZpbGUiOiJzcmMvYXBwL2Jhbmxpc3QvYmFubGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpbWd7XHJcbiAgICB3aWR0aDogNzVweDtcclxuICAgIGhlaWdodDogMTAwcHg7XHJcbn1cclxuXHJcblxyXG5cclxuaW9uLWxpc3R7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcclxufVxyXG5cclxuIiwiaW1nIHtcbiAgd2lkdGg6IDc1cHg7XG4gIGhlaWdodDogMTAwcHg7XG59XG5cbmlvbi1saXN0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/banlist/banlist.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/banlist/banlist.page.ts ***!
    \*****************************************/

  /*! exports provided: BanlistPage */

  /***/
  function srcAppBanlistBanlistPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BanlistPage", function () {
      return BanlistPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _provider_ygo_database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../provider/ygo/database.service */
    "./src/app/provider/ygo/database.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var BanlistPage = /*#__PURE__*/function () {
      function BanlistPage(database, router) {
        _classCallCheck(this, BanlistPage);

        this.database = database;
        this.router = router;
        this.searchCard = [];
        this.allList = [];
        this.limited = [];
        this.semi = [];
        this.banned = [];
        this.options = [{
          name: "Todas",
          checked: true
        }, {
          name: "Banidas",
          checked: false
        }, {
          name: "Limitadas",
          checked: false
        }, {
          name: "Semi-Limitadas",
          checked: false
        }];
        this.isSearch = false;
        this.banlist = this.getAllBanData();
        this.organizeCards();
      }

      _createClass(BanlistPage, [{
        key: "getAllBanData",
        value: function getAllBanData() {
          return this.database.getAllBanData();
        }
      }, {
        key: "color",
        value: function color(cor) {
          console.log(cor);
        }
      }, {
        key: "searchBanCard",
        value: function searchBanCard(event) {
          var searchTerm = event.srcElement.value;

          if (searchTerm && searchTerm.trim() != '') {
            var _iterator = _createForOfIteratorHelper(this.options),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var option = _step.value;
                option.checked = false;
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            this.isSearch = true;
            this.searchCard = this.allList.filter(function (item) {
              return item.cardName.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
            });
          } else {
            this.isSearch = false;
            this.options[0].checked = true;
          }
        }
      }, {
        key: "treatString",
        value: function treatString(string) {
          var cardType;

          if (string.indexOf("Fusion") !== -1) {
            cardType = string;
          } else if (string.indexOf("Synchro") !== -1) {
            cardType = string;
          } else if (string.indexOf("XYZ") !== -1) {
            cardType = string;
          } else if (string.indexOf("Effect") !== -1) {
            cardType = string;
          } else if (string.indexOf("Normal") !== -1) {
            cardType = string;
          } else if (string.indexOf("Ritual") !== -1) {
            cardType = string;
          } else if (string.indexOf("Link") !== -1) {
            cardType = string;
          } else if (string.indexOf("Spell") !== -1) {
            cardType = string;
          } else if (string.indexOf("Trap") !== -1) {
            cardType = string;
          } else if (string.indexOf("Tuner") !== -1) {
            cardType = string;
          } else if (string.indexOf("Spirit") !== -1) {
            cardType = string;
          } else if (string.indexOf("Gemini") !== -1) {
            cardType = string;
          }

          return cardType;
        }
      }, {
        key: "organizeCards",
        value: function organizeCards() {
          var _this = this;

          this.banlist.then(function (response) {
            var _iterator2 = _createForOfIteratorHelper(response),
                _step2;

            try {
              for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                var card = _step2.value;
                var banStatus = card.banlist_info.ban_tcg;

                if (banStatus === "Limited") {
                  _this.limited.push({
                    cardId: card.id,
                    cardName: card.name,
                    cardStatus: banStatus,
                    imgPath: card.card_images[0].image_url_small,
                    cardType: _this.treatString(card.type)
                  });
                } else if (banStatus === "Semi-Limited") {
                  _this.semi.push({
                    cardId: card.id,
                    cardName: card.name,
                    cardStatus: banStatus,
                    imgPath: card.card_images[0].image_url_small,
                    cardType: _this.treatString(card.type)
                  });
                } else if (banStatus === "Banned") {
                  _this.banned.push({
                    cardId: card.id,
                    cardName: card.name,
                    cardStatus: banStatus,
                    imgPath: card.card_images[0].image_url_small,
                    cardType: _this.treatString(card.type)
                  });
                }
              }
            } catch (err) {
              _iterator2.e(err);
            } finally {
              _iterator2.f();
            }

            _this.allList = _this.limited.concat(_this.semi, _this.banned);
          });
        }
      }, {
        key: "goToDetails",
        value: function goToDetails(name, type) {
          var navigationExtras = {
            state: {
              page: "banlist",
              type: type
            }
          };
          this.router.navigate(['/card-detail/' + name], navigationExtras);
        }
      }, {
        key: "backToMenu",
        value: function backToMenu() {
          console.log("voltar");
          this.router.navigate(['/home']);
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return BanlistPage;
    }();

    BanlistPage.ctorParameters = function () {
      return [{
        type: _provider_ygo_database_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }];
    };

    BanlistPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-banlist',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./banlist.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/banlist/banlist.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./banlist.page.scss */
      "./src/app/banlist/banlist.page.scss"))["default"]]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_provider_ygo_database_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])], BanlistPage);
    /***/
  }
}]);
//# sourceMappingURL=banlist-banlist-module-es5.js.map