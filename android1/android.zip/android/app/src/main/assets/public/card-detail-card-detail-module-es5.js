function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["card-detail-card-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/card-detail/card-detail.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/card-detail/card-detail.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCardDetailCardDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-row>\n      <ion-col size=\"3\">\n        <ion-icon name=\"arrow-back\" (click)=\"backToPage()\" class=\"icon-back\"></ion-icon>\n      </ion-col>\n      <ion-col size=\"9\">\n        <h3>{{name}}</h3>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list *ngFor=\"let card of cardDetail | async\" class=\"{{cardType}}\">\n    <ion-row>\n      <ion-col>\n        <ion-img src={{card.card_images[0].image_url}}></ion-img>\n      </ion-col>\n    </ion-row>\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"4\" class=\"description title\">Nome</ion-col>\n        <ion-col class=\"description\">{{card.name}}</ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"card.type != 'Spell Card' && card.type != 'Trap Card'\">\n        <ion-col size=\"4\" class=\"description  title\">Atributo</ion-col>\n        <ion-col class=\"description\">{{card.attribute}}</ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\" class=\"description title\">Tipos</ion-col>\n        <ion-col class=\"description\">{{card.race}} {{card.type}}</ion-col>\n      </ion-row>\n      <div *ngIf=\"cardType.indexOf('Link') !== -1\">\n      <ion-row>\n        <ion-col size=\"4\" class=\"description title\">Setas Link</ion-col>\n        <ion-col class=\"description\"><ion-col *ngFor=\"let linkmarker of card.linkmarkers\" size=\"2\">{{linkmarker}}</ion-col></ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\" class=\"description title\">Valor Link</ion-col>\n        <ion-col class=\"description\">{{card.linkval}}</ion-col>\n      </ion-row>\n      </div>\n      <ion-row *ngIf=\"card.type != 'Spell Card' && card.type != 'Trap Card' && card.type.indexOf('Link') === -1\">\n        <ion-col *ngIf=\"card.type.indexOf('XYZ') === -1\" size=\"4\" class=\"description title\">Nível</ion-col>\n        <ion-col *ngIf=\"card.type.indexOf('XYZ') !== -1\" size=\"4\" class=\"description title\">Rank</ion-col>\n        <ion-col class=\"description\">{{card.level}}</ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"cardType.indexOf('Pendulum') !== -1\">\n        <ion-col size=\"4\" class=\"description title\">Escala</ion-col>\n        <ion-col class=\"description\">{{card.scale}}</ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"card.type != 'Spell Card' && card.type != 'Trap Card'\">\n        <ion-col size=\"4\" class=\"description  title\">ATK / DEF</ion-col>\n        <ion-col class=\"description\">{{card.atk}} / {{card.def}}</ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\" class=\"description  title\">ID</ion-col>\n        <ion-col class=\"description\">{{card.id}}</ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"4\" class=\"description  title\">Status Banlist</ion-col>\n        <ion-col class=\"{{card.banlist_info.ban_tcg}} description\">{{card.banlist_info.ban_tcg}}</ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"12\" class=\"description title\">\n          Descrição ou Efeito\n        </ion-col>\n        <ion-col class=\"description\">\n          {{card.desc}}\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <ion-item button (click)=\"showPrices()\" class=\"whiteBackground\">\n      <h5>{{priceTitle}}</h5>\n    </ion-item>\n    <div *ngIf=\"showPrice\">\n      <ion-row>\n        <ion-col class=\"description title\">\n          *OBS: Os preços estão em dólar(U$).\n        </ion-col>\n      </ion-row>\n      <ion-list *ngFor = \"let cardSet of card.card_sets\">\n        <ion-item button (click)=\"showSetDetails(cardSet.set_code, cardSet.set_rarity)\" class=\"whiteBackground\">\n          {{cardSet.set_code}} - {{cardSet.set_rarity}}\n        </ion-item>\n        <div *ngIf=\"showSetDetail && cardSet.set_code === card_Set.setId && cardSet.set_rarity === card_Set.setRarity\">\n          <ion-grid>\n            <ion-row>\n              <ion-col size=\"4\" class=\"description title\">\n                Set\n              </ion-col>\n              <ion-col class=\"description\">\n                {{cardSet.set_name}}\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col size=\"4\" class=\"description title\">\n                Raridade\n              </ion-col>\n              <ion-col class=\"description\">\n                {{cardSet.set_rarity}}\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col size=\"4\" class=\"description title\">\n                Preço\n              </ion-col>\n              <ion-col class=\"description\">\n                U$ {{cardSet.set_price}}\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-list>\n    </div>\n  </ion-list>\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/card-detail/card-detail.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/card-detail/card-detail.module.ts ***!
    \***************************************************/

  /*! exports provided: CardDetailPageModule */

  /***/
  function srcAppCardDetailCardDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CardDetailPageModule", function () {
      return CardDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");
    /* harmony import */


    var _card_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./card-detail.page */
    "./src/app/card-detail/card-detail.page.ts");

    var routes = [{
      path: '',
      component: _card_detail_page__WEBPACK_IMPORTED_MODULE_6__["CardDetailPage"]
    }];

    var CardDetailPageModule = function CardDetailPageModule() {
      _classCallCheck(this, CardDetailPageModule);
    };

    CardDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_card_detail_page__WEBPACK_IMPORTED_MODULE_6__["CardDetailPage"]]
    })], CardDetailPageModule);
    /***/
  },

  /***/
  "./src/app/card-detail/card-detail.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/card-detail/card-detail.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCardDetailCardDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".description {\n  border-width: 0.01em;\n  border-style: solid;\n  background-color: #ffffff;\n}\n\n.title {\n  font-weight: bold;\n  background-color: gainsboro;\n}\n\n.XYZ {\n  --ion-background-color: black;\n  color: black !important;\n}\n\n.whiteBackground {\n  --ion-background-color: #ffffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2FyZC1kZXRhaWwvRDpcXFBhcmEgbyBvdXRybyBwY1xcRG9jdW1lbnRvc1xcUHJvamV0b3MgUHJvcHJpb3NcXHlnb0NhbGN1bGF0b3JcXHlnb0NhbGN1bGF0b3Ivc3JjXFxhcHBcXGNhcmQtZGV0YWlsXFxjYXJkLWRldGFpbC5wYWdlLnNjc3MiLCJzcmMvYXBwL2NhcmQtZGV0YWlsL2NhcmQtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQ0NKOztBREVBO0VBQ0ksaUJBQUE7RUFDQSwyQkFBQTtBQ0NKOztBREVBO0VBQ0ksNkJBQUE7RUFDQSx1QkFBQTtBQ0NKOztBREVBO0VBQ0ksK0JBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL2NhcmQtZGV0YWlsL2NhcmQtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kZXNjcmlwdGlvbntcclxuICAgIGJvcmRlci13aWR0aDogLjAxZW07XHJcbiAgICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcclxufVxyXG5cclxuLnRpdGxle1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBnYWluc2Jvcm87XHJcbn1cclxuXHJcbi5YWVp7XHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcclxuICAgIGNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ud2hpdGVCYWNrZ3JvdW5ke1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcclxufVxyXG4iLCIuZGVzY3JpcHRpb24ge1xuICBib3JkZXItd2lkdGg6IDAuMDFlbTtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbn1cblxuLnRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGJhY2tncm91bmQtY29sb3I6IGdhaW5zYm9ybztcbn1cblxuLlhZWiB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICBjb2xvcjogYmxhY2sgIWltcG9ydGFudDtcbn1cblxuLndoaXRlQmFja2dyb3VuZCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/card-detail/card-detail.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/card-detail/card-detail.page.ts ***!
    \*************************************************/

  /*! exports provided: CardDetailPage */

  /***/
  function srcAppCardDetailCardDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CardDetailPage", function () {
      return CardDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _provider_ygo_database_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../provider/ygo/database.service */
    "./src/app/provider/ygo/database.service.ts");

    var CardDetailPage = /*#__PURE__*/function () {
      function CardDetailPage(route, router, database) {
        _classCallCheck(this, CardDetailPage);

        this.route = route;
        this.router = router;
        this.database = database;
        this.showPrice = false;
        this.priceTitle = "Mostrar preços";
        this.showSetDetail = false;
        this.name = this.getId();
        this.cardDetail = this.getCardDetail();
        this.getPageToBackData();
        console.log(this.cardType);
      }

      _createClass(CardDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "getId",
        value: function getId() {
          return this.route.snapshot.paramMap.get('name');
        }
      }, {
        key: "getPageToBackData",
        value: function getPageToBackData() {
          var getNav = this.router.getCurrentNavigation();

          if (getNav.extras.state) {
            this.pageToBack = getNav.extras.state.page;
            this.cardType = getNav.extras.state.type;
          }
        }
      }, {
        key: "getCardDetail",
        value: function getCardDetail() {
          return this.database.getSpecificCard(this.name);
        }
      }, {
        key: "backToPage",
        value: function backToPage() {
          if (this.pageToBack === "banlist") {
            this.router.navigate(['/banlist']);
          }
        }
      }, {
        key: "showPrices",
        value: function showPrices() {
          if (this.showPrice === true) {
            this.showPrice = false;
            this.priceTitle = "Mostrar preços";
          } else {
            this.showPrice = true;
            this.priceTitle = "Ocultar preços";
          }
        }
      }, {
        key: "showSetDetails",
        value: function showSetDetails(setId, setRarity) {
          this.card_Set = {
            setId: setId,
            setRarity: setRarity
          };

          if (this.showSetDetail === true) {
            this.showSetDetail = false;
          } else {
            this.showSetDetail = true;
          }
        }
      }]);

      return CardDetailPage;
    }();

    CardDetailPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _provider_ygo_database_service__WEBPACK_IMPORTED_MODULE_3__["DatabaseService"]
      }];
    };

    CardDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-card-detail',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./card-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/card-detail/card-detail.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./card-detail.page.scss */
      "./src/app/card-detail/card-detail.page.scss"))["default"]]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _provider_ygo_database_service__WEBPACK_IMPORTED_MODULE_3__["DatabaseService"]])], CardDetailPage);
    /***/
  }
}]);
//# sourceMappingURL=card-detail-card-detail-module-es5.js.map