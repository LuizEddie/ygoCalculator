function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
  /***/
  "./node_modules/capacitor-admob/dist/esm/definitions.js":
  /*!**************************************************************!*\
    !*** ./node_modules/capacitor-admob/dist/esm/definitions.js ***!
    \**************************************************************/

  /*! exports provided: AdSize, AdPosition */

  /***/
  function node_modulesCapacitorAdmobDistEsmDefinitionsJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AdSize", function () {
      return AdSize;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AdPosition", function () {
      return AdPosition;
    });
    /*
    *  For more information
    *   Read:  https://developers.google.com/android/reference/com/google/android/gms/ads/AdSize
    * */


    var AdSize;

    (function (AdSize) {
      // Mobile Marketing Association (MMA)
      // banner ad size (320x50 density-independent pixels).
      AdSize["BANNER"] = "BANNER"; // A dynamically sized banner that matches its parent's
      // width and expands/contracts its height to match the ad's
      // content after loading completes.

      AdSize["FLUID"] = "FLUID"; //Interactive Advertising Bureau (IAB)
      // full banner ad size (468x60 density-independent pixels).

      AdSize["FULL_BANNER"] = "FULL_BANNER"; // Large banner ad size (320x100 density-independent pixels).

      AdSize["LARGE_BANNER"] = "LARGE_BANNER"; // Interactive Advertising Bureau (IAB)
      // leaderboard ad size (728x90 density-independent pixels).

      AdSize["LEADERBOARD"] = "LEADERBOARD"; // Interactive Advertising Bureau (IAB)
      // medium rectangle ad size (300x250 density-independent pixels).

      AdSize["MEDIUM_RECTANGLE"] = "MEDIUM_RECTANGLE"; // A dynamically sized banner that is full-width and auto-height.

      AdSize["SMART_BANNER"] = "SMART_BANNER"; // A special variant of FLUID to be set on SearchAdView when
      // loading a DynamicHeightSearchAdRequest.
      // SEARCH = 'SEARCH',
      // IAB wide skyscraper ad size (160x600 density-independent pixels).
      // This size is currently not supported by the Google Mobile Ads network;
      // this is intended for mediation ad networks only.
      // WIDE_SKYSCRAPER = 'WIDE_SKYSCRAPER',
      // To define a custom banner size, set your desired AdSize

      AdSize["CUSTOM"] = "CUSTOM";
    })(AdSize || (AdSize = {}));
    /*
    *
    * More information
    * https://developer.android.com/reference/android/widget/LinearLayout#attr_android:gravity
    * */


    var AdPosition;

    (function (AdPosition) {
      AdPosition["TOP_CENTER"] = "TOP_CENTER";
      AdPosition["CENTER"] = "CENTER";
      AdPosition["BOTTOM_CENTER"] = "BOTTOM_CENTER";
    })(AdPosition || (AdPosition = {})); //# sourceMappingURL=definitions.js.map

    /***/

  },

  /***/
  "./node_modules/capacitor-admob/dist/esm/index.js":
  /*!********************************************************!*\
    !*** ./node_modules/capacitor-admob/dist/esm/index.js ***!
    \********************************************************/

  /*! exports provided: AdSize, AdPosition */

  /***/
  function node_modulesCapacitorAdmobDistEsmIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var _definitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! ./definitions */
    "./node_modules/capacitor-admob/dist/esm/definitions.js");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "AdSize", function () {
      return _definitions__WEBPACK_IMPORTED_MODULE_0__["AdSize"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "AdPosition", function () {
      return _definitions__WEBPACK_IMPORTED_MODULE_0__["AdPosition"];
    }); //# sourceMappingURL=index.js.map

    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
  /*!***************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\n  <ion-grid class=\"center-grid\">\n    <ion-row class=\"parent-row\">\n      <ion-col size=\"12\">\n        <ion-button (click)=\"tipoDuelo()\" expand=\"block\"><ion-icon name=\"calculator\"></ion-icon>Duelo</ion-button>\n      </ion-col>\n    </ion-row>\n      <ion-row class=\"parent-row\">\n      <ion-col size=\"6\">\n        <ion-button expand=\"block\" (click)=\"openBanlist()\"><ion-icon name=\"warning\"></ion-icon>Banlist</ion-button>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-button expand=\"block\" (click)=\"openCardList()\"><ion-icon name=\"briefcase\"></ion-icon>Cards</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n<ion-footer>\n  <ion-toolbar>\n    Versão: 1.0 - Desenvolvido por: Luiz Eduardo da Silva Magalhães - YU-GI-OH Copyright© 1997 - {{year}} Kazuki Takahashi/Konami Corp.\n  </ion-toolbar>\n</ion-footer>\n";
    /***/
  },

  /***/
  "./src/app/home/home.module.ts":
  /*!*************************************!*\
    !*** ./src/app/home/home.module.ts ***!
    \*************************************/

  /*! exports provided: HomePageModule */

  /***/
  function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
      return HomePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/home/home.page.ts");

    var HomePageModule = function HomePageModule() {
      _classCallCheck(this, HomePageModule);
    };

    HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
      }])],
      declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })], HomePageModule);
    /***/
  },

  /***/
  "./src/app/home/home.page.scss":
  /*!*************************************!*\
    !*** ./src/app/home/home.page.scss ***!
    \*************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-grid.center-grid {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%) !important;\n  display: block !important;\n  width: 100%;\n  height: 50%;\n}\n\nion-row.parent-row {\n  height: 50% !important;\n  justify-content: center !important;\n}\n\nion-button {\n  height: 100%;\n  font-size: 125%;\n}\n\nion-content {\n  --background: grey !important;\n}\n\nion-toolbar {\n  --background: black !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9EOlxcUGFyYSBvIG91dHJvIHBjXFxEb2N1bWVudG9zXFxQcm9qZXRvcyBQcm9wcmlvc1xceWdvQ2FsY3VsYXRvclxceWdvQ2FsY3VsYXRvci9zcmNcXGFwcFxcaG9tZVxcaG9tZS5wYWdlLnNjc3MiLCJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDUSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsMkNBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FDQ1I7O0FERUE7RUFDSSxzQkFBQTtFQUVBLGtDQUFBO0FDQUo7O0FER0E7RUFDSSxZQUFBO0VBQ0EsZUFBQTtBQ0FKOztBREdBO0VBQ0ksNkJBQUE7QUNBSjs7QURHQTtFQUNJLDhCQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWdyaWQuY2VudGVyLWdyaWQge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHRvcDogNTAlO1xuICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpICFpbXBvcnRhbnQ7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBoZWlnaHQ6IDUwJTtcbn1cblxuaW9uLXJvdy5wYXJlbnQtcm93e1xuICAgIGhlaWdodDogNTAlICFpbXBvcnRhbnQ7XG4gICAgLy9hbGlnbi1pdGVtczogY2VudGVyICFpbXBvcnRhbnQ7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbn1cblxuaW9uLWJ1dHRvbntcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgZm9udC1zaXplOiAxMjUlXG59XG5cbmlvbi1jb250ZW50e1xuICAgIC0tYmFja2dyb3VuZDogZ3JleSAhaW1wb3J0YW50O1xufVxuXG5pb24tdG9vbGJhcntcbiAgICAtLWJhY2tncm91bmQ6IGJsYWNrICFpbXBvcnRhbnQ7XG59IiwiaW9uLWdyaWQuY2VudGVyLWdyaWQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTAlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpICFpbXBvcnRhbnQ7XG4gIGRpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDUwJTtcbn1cblxuaW9uLXJvdy5wYXJlbnQtcm93IHtcbiAgaGVpZ2h0OiA1MCUgIWltcG9ydGFudDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIGhlaWdodDogMTAwJTtcbiAgZm9udC1zaXplOiAxMjUlO1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogZ3JleSAhaW1wb3J0YW50O1xufVxuXG5pb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogYmxhY2sgIWltcG9ydGFudDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/home/home.page.ts":
  /*!***********************************!*\
    !*** ./src/app/home/home.page.ts ***!
    \***********************************/

  /*! exports provided: HomePage */

  /***/
  function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePage", function () {
      return HomePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/dist/fesm5.js");
    /* harmony import */


    var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/network/ngx */
    "./node_modules/@ionic-native/network/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @capacitor/core */
    "./node_modules/@capacitor/core/dist/esm/index.js");
    /* harmony import */


    var capacitor_admob__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! capacitor-admob */
    "./node_modules/capacitor-admob/dist/esm/index.js");

    var AdMob = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"].AdMob;

    var HomePage = /*#__PURE__*/function () {
      function HomePage(alertController, router, network) {
        _classCallCheck(this, HomePage);

        this.alertController = alertController;
        this.router = router;
        this.network = network;
        this.year = this.getYear();
        this.showBanner();
      }

      _createClass(HomePage, [{
        key: "tipoDuelo",
        value: function tipoDuelo() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertController.create();

                  case 2:
                    alert = _context.sent;
                    alert.title = "Formato";
                    alert.subHeader = "Escolha o formato do duelo";
                    alert.buttons = [{
                      text: "Classico",
                      handler: function handler() {
                        var navigationExtras = {
                          state: {
                            tipo: "dueloClassico",
                            layout: "fieldCenter"
                          }
                        };

                        _this.router.navigate(['/duelo'], navigationExtras);
                      }
                    }, {
                      text: "Speed",
                      handler: function handler() {
                        var navigationExtras = {
                          state: {
                            tipo: "speedDuel",
                            layout: "fieldCenter"
                          }
                        };

                        _this.router.navigate(['/duelo'], navigationExtras);
                      }
                    }];
                    alert.present();

                  case 7:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "openBanlist",
        value: function openBanlist() {
          var connection = this.checkConnection();
          connection === "Conectado" ? this.router.navigate(['/banlist']) : alert("Necessário internet para usar essa função!");
        }
      }, {
        key: "openCardList",
        value: function openCardList() {
          var connection = this.checkConnection();
          connection === "Conectado" ? alert("Implementado") : alert("Necessário internet para usar essa função!");
        }
      }, {
        key: "getYear",
        value: function getYear() {
          var data = new Date();
          return data.getFullYear();
        }
      }, {
        key: "checkConnection",
        value: function checkConnection() {
          var netState = this.network.type;
          var con = netState !== 'none' ? "Conectado" : "Desconectado";
          return con;
        }
      }, {
        key: "showBanner",
        value: function showBanner() {
          var options = {
            adId: "ca-app-pub-6210301466309831/2664181112",
            adSize: capacitor_admob__WEBPACK_IMPORTED_MODULE_6__["AdSize"].BANNER,
            position: capacitor_admob__WEBPACK_IMPORTED_MODULE_6__["AdPosition"].BOTTOM_CENTER
          };
          AdMob.showBanner(options).then(function (value) {
            console.log(value);
          }, function (error) {
            console.log(error);
          });
        }
      }]);

      return HomePage;
    }();

    HomePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_4__["Network"]
      }];
    };

    HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./home.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./home.page.scss */
      "./src/app/home/home.page.scss"))["default"]]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_4__["Network"]])], HomePage);
    /***/
  }
}]);
//# sourceMappingURL=home-home-module-es5.js.map